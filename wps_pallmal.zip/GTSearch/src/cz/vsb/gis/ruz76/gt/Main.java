/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.vsb.gis.ruz76.gt;

/**
 *
 * @author jencek
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Examples e = new Examples();
        //System.out.println(e.search("600000 4920000", 10000.0d));
        //System.out.println(e.prekryv("600000 4920000", 10000.0d));
        //System.out.println(e.bbox("M"));
        //System.out.println(e.wfs("sf_restricted"));
        //System.out.println(e.testREST_PUT_Local());
        //System.out.println(e.overlayWMS("600000 4920000", 5000.0d));
        //System.out.println(e.postGIS_example1());
        //System.out.println(e.postGIS_example2("600000 4920000", 5000.0d));
        //System.out.println(e.networking("Ostrava", "Fulnek"));
        //System.out.println(e.overlayCollectionOutput("600000 4920000", 5000.0d));
    }
    
}
